# Complete Environment Setup Guide

Step-by-step visual guide to setting up your Paper Portal with Appwrite.

---

## Part 1: Get Appwrite Credentials

### Step 1: Create Appwrite Account
1. Visit https://cloud.appwrite.io
2. Click "Sign up"
3. Create account with email & password
4. Verify email

### Step 2: Create Project
1. In dashboard, click "Create project"
2. Name: `Paper Portal` (or your choice)
3. Click "Create"
4. **Copy your Project ID** from project settings

### Step 3: Create API Key
1. Go to **Settings → API Keys**
2. Click "Create API Key"
3. Name: `Paper Portal API`
4. Select these scopes:
   - ☑ databases.read
   - ☑ databases.write
   - ☑ collections.read
   - ☑ collections.write
   - ☑ documents.read
   - ☑ documents.write
   - ☑ documents.delete
   - ☑ files.read
   - ☑ files.write
   - ☑ files.delete
5. Click "Create"
6. **Copy the API Key** and save securely

### You Now Have:
```
NEXT_PUBLIC_APPWRITE_ENDPOINT = https://cloud.appwrite.io/v1
NEXT_PUBLIC_APPWRITE_PROJECT_ID = (copied above)
APPWRITE_API_KEY = (copied above)
```

---

## Part 2: Create Database & Collections

### Step 1: Create Database
1. In Appwrite console, go to **Databases**
2. Click "Create database"
3. Name: `papers_database`
4. Click "Create"
5. **Copy Database ID**

### Step 2: Create Papers Collection
1. Inside `papers_database`, click "Create collection"
2. Collection ID: `papers`
3. Name: `Papers`
4. Click "Create"

**Add Attributes:**

| Attribute | Type | Required | Indexed |
|-----------|------|----------|---------|
| title | String | ✓ | ✓ |
| department | String | ✓ | ✓ |
| year | Integer | ✓ | ✓ |
| semester | String | ✓ | ✓ |
| season | String | ✓ | ✓ |
| subject | String | ✓ | ✗ |
| fileId | String | ✓ | ✗ |
| fileName | String | ✓ | ✗ |
| uploadedAt | DateTime | ✓ | ✓ |
| uploadedBy | String | ✓ | ✗ |

### Step 3: Create Users Collection
1. Click "Create collection"
2. Collection ID: `users`
3. Name: `Users`

**Add Attributes:**

| Attribute | Type | Required | Unique |
|-----------|------|----------|--------|
| email | String | ✓ | ✓ |
| name | String | ✗ | ✗ |
| department | String | ✗ | ✗ |
| enrollmentNo | String | ✗ | ✗ |
| createdAt | DateTime | ✗ | ✗ |

### Step 4: Create Admins Collection
1. Click "Create collection"
2. Collection ID: `admins`
3. Name: `Admins`

**Add Attributes:**

| Attribute | Type | Required | Unique |
|-----------|------|----------|--------|
| email | String | ✓ | ✓ |
| name | String | ✗ | ✗ |
| role | String | ✓ | ✗ |
| createdAt | DateTime | ✗ | ✗ |

---

## Part 3: Create Storage Bucket

### Step 1: Create Bucket
1. Go to **Storage**
2. Click "Create bucket"
3. Bucket ID: `papers_bucket`
4. Name: `Papers Bucket`
5. Click "Create"
6. **Copy Bucket ID**

### Step 2: Set Permissions
1. In bucket settings, go to **Permissions**
2. Set:
   - Public: Read (so users can download)
   - Authenticated: Write (only admins can upload)

---

## Part 4: Setup Your Project

### Step 1: Copy Environment Template
```bash
# Navigate to your project folder
cd paper-portal

# Copy the template
cp .env.example .env.local
```

### Step 2: Edit .env.local File

Open `.env.local` in your text editor and fill in:

```env
# From Appwrite Settings
NEXT_PUBLIC_APPWRITE_ENDPOINT=https://cloud.appwrite.io/v1
NEXT_PUBLIC_APPWRITE_PROJECT_ID=YOUR_PROJECT_ID
APPWRITE_API_KEY=YOUR_API_KEY

# From Database Creation
NEXT_PUBLIC_APPWRITE_DATABASE_ID=papers_database
NEXT_PUBLIC_APPWRITE_PAPERS_COLLECTION_ID=papers
NEXT_PUBLIC_APPWRITE_USERS_COLLECTION_ID=users
NEXT_PUBLIC_APPWRITE_ADMINS_COLLECTION_ID=admins

# From Storage Creation
NEXT_PUBLIC_APPWRITE_BUCKET_ID=papers_bucket

# Demo Credentials
ADMIN_EMAIL=admin@university.edu
ADMIN_PASSWORD=admin123

# App Settings
NEXT_PUBLIC_APP_NAME=Paper Portal
NEXT_PUBLIC_APP_URL=http://localhost:3000
NODE_ENV=development
```

### Step 3: Verify Setup
```bash
# Your .env.local should have all values filled in
# Make sure no value says "your_..." or "..."
```

### Step 4: Add to .gitignore
Make sure `.env.local` is in `.gitignore`:
```bash
# Open or create .gitignore
# Add this line:
.env.local
```

---

## Part 5: Install & Run

### Step 1: Install Dependencies
```bash
npm install
```

### Step 2: Start Development Server
```bash
npm run dev
```

### Step 3: Open in Browser
Visit: **http://localhost:3000**

You should see the Paper Portal home page! ✓

---

## Part 6: Test Admin Login

### Access Admin Panel
1. Click "Admin Login" on homepage
2. Or go to: http://localhost:3000/admin

### Login with Demo Credentials
```
Email:    admin@university.edu
Password: admin123
```

You should see the admin dashboard! ✓

---

## Part 7: Upload Test Paper

### From Admin Dashboard
1. Click "Upload Papers"
2. Fill in:
   - Title: "Test DSA Paper"
   - Department: "CSE"
   - Year: 2024
   - Semester: 3
   - Season: Winter
   - Subject: "Data Structures"
3. Select any PDF file
4. Click "Upload"

You should get success message! ✓

---

## Part 8: View Student Side

### Visit Paper Page
1. Go to home page: http://localhost:3000
2. Click "Computer Science (CSE)"
3. Click "Browse Papers"
4. You should see your uploaded paper! ✓

---

## Part 9: Test More Features

### Try These:
- ☑ Filter papers by year
- ☑ Filter papers by semester
- ☑ Download a PDF
- ☑ Delete a paper from `/admin/manage`
- ☑ Upload multiple papers
- ☑ Try different departments

---

## Complete! 🎉

Your Paper Portal is now:
- ✅ Connected to Appwrite
- ✅ Storing papers in database
- ✅ Uploading PDFs to storage
- ✅ Working end-to-end

### Next Steps:
1. Upload more papers
2. Customize departments
3. Invite other admins
4. Plan deployment
5. Set up monitoring

---

## Troubleshooting Quick Fix

### "Blank page" or "Error loading"
**Fix:** Check browser console (F12 → Console tab)
```
✓ Check if NEXT_PUBLIC_APPWRITE_PROJECT_ID is correct
✓ Check if APPWRITE_API_KEY is correct
✓ Verify all collections created in Appwrite
✓ Check network tab for failed requests
```

### "Login doesn't work"
**Fix:**
```
✓ Clear browser localStorage (F12 → Storage → Local Storage → Clear)
✓ Try with exact credentials:
   Email:    admin@university.edu
   Password: admin123
```

### "File upload fails"
**Fix:**
```
✓ Check bucket exists in Appwrite Storage
✓ Verify bucket ID in .env.local
✓ Check file is PDF (not Word doc, image, etc.)
✓ Ensure file size < 50MB
```

### "Papers don't appear"
**Fix:**
```
✓ Verify you uploaded without errors
✓ Check Appwrite Console → Database → Papers collection
✓ Manually refresh page
✓ Clear browser cache
```

---

## Environment Variables Reference

```
VARIABLE                              WHERE TO GET IT
───────────────────────────────────────────────────────────────
NEXT_PUBLIC_APPWRITE_ENDPOINT    →    Always: https://cloud.appwrite.io/v1
NEXT_PUBLIC_APPWRITE_PROJECT_ID  →    Appwrite Console → Settings
APPWRITE_API_KEY                 →    Appwrite Console → Settings → API Keys
NEXT_PUBLIC_APPWRITE_DATABASE_ID →    Appwrite Console → Databases (what you named it)
NEXT_PUBLIC_APPWRITE_PAPERS_COLLECTION_ID → Appwrite Console → Collections
NEXT_PUBLIC_APPWRITE_BUCKET_ID   →    Appwrite Console → Storage
```

---

## Secure Your Setup

Before sharing or deploying:

✅ Never share `.env.local` file  
✅ Don't commit `.env.local` to Git  
✅ Use different API keys for production  
✅ Rotate API keys periodically  
✅ Set proper permissions in Appwrite  
✅ Monitor access logs  
✅ Use HTTPS in production  

---

## File Checklist

After setup, verify these files exist:

```
paper-portal/
├── .env.local              ← Your secrets (NOT in git)
├── .env.example            ← Template (safe to commit)
├── .env.local.example      ← Detailed template
├── lib/
│   ├── appwrite.ts         ← Appwrite client
│   ├── papers-service.ts   ← Paper operations
│   └── auth-service.ts     ← Auth logic
├── APPWRITE_README.md      ← Overview
├── APPWRITE_SETUP.md       ← Full guide
├── APPWRITE_CHECKLIST.md   ← Checklist
└── ENV_SETUP_GUIDE.md      ← This file
```

---

## Support

If stuck:
1. Re-read this guide carefully
2. Check APPWRITE_SETUP.md troubleshooting
3. Visit https://appwrite.io/docs
4. Check browser console (F12)
5. Check Appwrite Console logs

---

## You're All Set! 🚀

Your Paper Portal with Appwrite is ready to go!

**Start uploading papers and enjoy your portal!**

For more info: See APPWRITE_README.md, APPWRITE_SETUP.md, or APPWRITE_CHECKLIST.md
