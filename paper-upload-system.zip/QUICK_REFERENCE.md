# Paper Portal - Quick Reference Guide

## 🚀 Quick Start

```bash
npm install
npm run dev
```

Open: **http://localhost:3000**

---

## 📍 Key Routes

### Student Routes
| Route | Purpose |
|-------|---------|
| `/` | Home - Browse departments |
| `/cse` | CSE department (years/semesters) |
| `/cse/papers?year=1&sem=1&season=Winter&paperYear=2025` | View papers with filters |
| `/entc` | ENTC department |
| `/civil` | Civil department |
| `/ie` | Information Engineering |
| `/mech` | Mechanical Engineering |
| `/electrical` | Electrical Engineering |

### Admin Routes
| Route | Purpose |
|-------|---------|
| `/admin` | Admin login |
| `/admin/dashboard` | Dashboard (after login) |
| `/admin/upload` | Upload new paper |
| `/admin/manage` | Manage/delete papers |
| `/admin/analytics` | View statistics |

---

## 🔐 Admin Access

**Demo Credentials:**
- Email: `admin@university.edu`
- Password: `admin123`

---

## 🎨 Department Colors

| Department | Color | Emoji |
|-----------|-------|-------|
| CSE | Blue | 💻 |
| ENTC | Purple | ⚡ |
| Civil | Amber | 🏗️ |
| IE | Green | 📊 |
| Mechanical | Red | ⚙️ |
| Electrical | Yellow | 🔌 |

---

## 📁 Important Files

### Pages to Customize
- `app/page.tsx` - Home page content
- `app/[dept]/page.tsx` - Department pages
- `app/admin/dashboard/page.tsx` - Admin dashboard

### Components to Modify
- `components/NavBar.tsx` - Navigation menu
- `components/Icons.tsx` - Icon definitions

### Global Files
- `app/layout.tsx` - Root layout
- `app/globals.css` - Global styles

---

## 🎯 Common Tasks

### Add New Department
```bash
1. Create app/[dept-name]/page.tsx
2. Create app/[dept-name]/papers/page.tsx
3. Create app/[dept-name]/papers/loading.tsx
4. Add to home page grid
```

### Add Navigation Link
Edit `components/NavBar.tsx` - Add new `<li>` item in nav-menu

### Change Department Colors
Search for color classes like `text-blue-600` and replace with desired color

### Update Admin Stats
Edit `app/admin/dashboard/page.tsx` - Modify `stats` array

### Add New Admin Feature
Create new folder in `app/admin/[feature-name]/page.tsx`

---

## 📊 Data Models

### Paper Structure
```typescript
{
  id: number;
  subject: string;
  department: string;
  year: number;           // 1-4
  semester: number;       // 1-8
  season: "Winter" | "Summer";
  paperYear: number;      // 2015-2026
  fileId: string;
  url: string;
}
```

### Filter Structure
```typescript
{
  department: string;
  year: string;
  semester: string;
  season: string;
  paperYear: string;
  search: string;
}
```

---

## 🎨 Tailwind Classes Used

### Common Utilities
```
p-4, m-4, gap-4          // Spacing
text-lg, text-3xl        // Font sizes
font-bold, font-medium   // Font weights
flex, grid               // Layout
rounded-lg, rounded-xl   // Border radius
shadow-md, shadow-lg     // Shadows
hover:, focus:           // States
md:, lg:                 // Responsive
```

---

## 🔄 Component Hierarchy

```
RootLayout
├── NavBar
└── Main Route
    ├── Home
    │   └── Department Grid
    ├── Department Page
    │   └── Year/Semester Structure
    ├── Papers Page
    │   └── Paper List
    └── Admin Pages
        ├── Login
        ├── Dashboard
        ├── Upload
        ├── Manage
        └── Analytics
```

---

## 📝 TypeScript Patterns

### Type Imports
```typescript
import type { Metadata } from 'next';
```

### Component Types
```typescript
export default function ComponentName() {
  // Client component
}

export default function ComponentName() {
  // Server component
}
```

### Form Handling
```typescript
const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
  // Handle input change
};
```

---

## 🎭 Styling Patterns

### Button Styles
```
Primary: bg-blue-600 text-white hover:bg-blue-700
Danger: bg-red-600 text-white hover:bg-red-700
Outline: border-2 border-blue-600 text-blue-600 hover:bg-blue-50
```

### Card Styles
```
bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition
```

### Form Inputs
```
border border-slate-300 rounded-lg p-2
focus:ring-2 focus:ring-blue-500 focus:border-transparent
```

---

## 🚀 Performance Tips

- Use Next.js Image component for images
- Optimize bundle with dynamic imports
- Use Suspense for slow components
- Cache database queries
- Minimize CSS

---

## 📱 Responsive Breakpoints

```
Mobile:  < 640px
Tablet:  640px - 1024px
Desktop: > 1024px

Usage: md:grid-cols-2 lg:grid-cols-3
```

---

## 🔍 Debugging

### Enable Debug Logs
```typescript
console.log("[v0] Message:", data);
```

### Check Auth Status
```typescript
const isAdmin = localStorage.getItem("adminAuth");
```

### Inspect Query Params
```typescript
const params = useSearchParams();
const year = params.get("year");
```

---

## 📚 File Naming

```
Page files:        page.tsx
Layout files:      layout.tsx
Loading states:    loading.tsx
CSS modules:       name.module.css
CSS files:         name.css
Components:        ComponentName.tsx
Types:             types.ts
Utils:             utils.ts
```

---

## 🎯 Key Features at a Glance

| Feature | Status | Location |
|---------|--------|----------|
| Home page | ✅ Complete | `/` |
| Department pages | ✅ Complete | `/:dept` |
| Paper viewer | ✅ Complete | `/:dept/papers` |
| Admin login | ✅ Complete | `/admin` |
| Upload papers | ✅ Complete | `/admin/upload` |
| Manage papers | ✅ Complete | `/admin/manage` |
| Analytics | ✅ Complete | `/admin/analytics` |
| Responsive design | ✅ Complete | All pages |
| Mobile menu | ✅ Complete | NavBar |

---

## 🛠️ Build Commands

```bash
# Install dependencies
npm install

# Development server
npm run dev

# Production build
npm run build

# Start production server
npm start

# Lint code
npm run lint

# Type check
npx tsc --noEmit
```

---

## 📦 Dependencies

Main dependencies:
- `next`: 16.0.0
- `react`: 19.0.0
- `tailwindcss`: Latest
- `lucide-react`: For icons

(All included in starter template)

---

## 🎓 Key Concepts

### Server Components
- Automatically server-rendered
- Can access databases directly
- Used for layouts and department pages

### Client Components
- Use "use client" directive
- Can use hooks (useState, useEffect)
- Used for admin pages and interactive pages

### Route Segments
- `[slug]` - Dynamic routes
- `/(group)` - Route groups
- `page.tsx` - Route entry point

---

## 🔗 Important Links

- [Next.js Docs](https://nextjs.org)
- [Tailwind CSS](https://tailwindcss.com)
- [Lucide Icons](https://lucide.dev)
- [React Docs](https://react.dev)

---

## ✅ Pre-Deployment Checklist

- [ ] Test all routes
- [ ] Check mobile responsiveness
- [ ] Verify admin login
- [ ] Test paper filtering
- [ ] Check all links work
- [ ] Verify images load
- [ ] Test forms
- [ ] Check console for errors
- [ ] Verify environment variables
- [ ] Build and test production build

---

## 💡 Pro Tips

1. **Use Tailwind Docs**: Copy class names directly
2. **Inspect Elements**: Use browser DevTools
3. **Check File Paths**: Ensure correct absolute paths
4. **Test Mobile First**: Design from small to large
5. **Reuse Components**: Don't repeat code
6. **Keep It Simple**: Don't over-engineer
7. **Document Changes**: Leave comments for future you
8. **Version Control**: Use Git for backups

---

## 🎯 Common Errors & Solutions

| Error | Solution |
|-------|----------|
| Page not found | Check file path and route |
| Styling broken | Clear browser cache |
| Auth not working | Check localStorage |
| Image not loading | Verify image path |
| Form not submitting | Check form validation |

---

## 🎉 You're All Set!

Your Paper Portal is ready to go. Start developing and have fun!

**Questions?** Check the documentation files included in the project.

---

**Last Updated**: February 6, 2026  
**Version**: 1.0.0  
**Status**: ✅ Production Ready
