# Complete Environment Configuration Guide

## Your .env.local Setup

Based on your Appwrite configuration, here's exactly what you need to set up:

### Step 1: Create .env.local File

In your project root, create a `.env.local` file with these exact variables:

```bash
VITE_APPWRITE_ENDPOINT=https://cloud.appwrite.io/v1
NEXT_PUBLIC_APPWRITE_PROJECT_ID=YOUR_PROJECT_ID_HERE
NEXT_PUBLIC_APPWRITE_DATABASE_ID=YOUR_DATABASE_ID_HERE

NEXT_PUBLIC_APPWRITE_COLLECTION_ID=question_papers
NEXT_PUBLIC_APPWRITE_BUCKET_ID=papers-bucket

ADMIN_EMAIL=admin@university.edu
ADMIN_PASSWORD=admin123
```

### Step 2: Get Your Appwrite Credentials

1. **Go to Appwrite Console**: https://cloud.appwrite.io
2. **Create/Select a Project**
3. **Copy Project ID**:
   - Click on your project
   - Settings → Project Settings
   - Copy the "Project ID"
   - Paste into `NEXT_PUBLIC_APPWRITE_PROJECT_ID`

4. **Create Database**:
   - Go to Databases
   - Create new database
   - Name: `papers` or any name you prefer
   - Copy the Database ID
   - Paste into `NEXT_PUBLIC_APPWRITE_DATABASE_ID`

5. **Create Collection**:
   - Inside your database, create Collection
   - Name: `question_papers` (matches COLLECTION_ID)
   - Create these attributes:
     ```
     - title (String, required)
     - department (String, required)
     - year (Integer, required)
     - semester (String, required)
     - season (String, required)
     - subject (String, required)
     - fileId (String, required)
     - fileName (String, required)
     - uploadedAt (DateTime, required)
     - uploadedBy (String, required)
     ```

6. **Create Storage Bucket**:
   - Go to Storage
   - Create new bucket
   - Name: `papers-bucket` (matches BUCKET_ID)
   - Enable file uploads
   - Set permissions to allow PDF uploads

### Step 3: Your Complete .env.local

After gathering all credentials, your file should look like:

```bash
# Appwrite Configuration
VITE_APPWRITE_ENDPOINT=https://cloud.appwrite.io/v1
NEXT_PUBLIC_APPWRITE_PROJECT_ID=6789abcdef012345ghij
NEXT_PUBLIC_APPWRITE_DATABASE_ID=papers_db_12345

# Database Collection & Storage
NEXT_PUBLIC_APPWRITE_COLLECTION_ID=question_papers
NEXT_PUBLIC_APPWRITE_BUCKET_ID=papers-bucket

# Admin Credentials
ADMIN_EMAIL=admin@university.edu
ADMIN_PASSWORD=admin123
```

### Step 4: Test Your Configuration

1. **Run the project**:
   ```bash
   npm install
   npm run dev
   ```

2. **Check for errors**:
   - Open http://localhost:3000
   - Go to /admin to test login
   - Try uploading a test PDF

3. **Debug if needed**:
   - Check browser console for errors
   - Check that all env variables are set
   - Verify Appwrite collection/bucket exist

## Troubleshooting

### Issue: "Missing environment variables"
**Solution**: Make sure `.env.local` is in the project root, not in any subdirectory.

### Issue: "Collection not found"
**Solution**: 
- Verify collection name is exactly `question_papers`
- Check database ID is correct
- Ensure all attributes are created

### Issue: "File upload fails"
**Solution**:
- Check bucket name is `papers-bucket`
- Ensure bucket permissions allow file uploads
- Check file size isn't too large

### Issue: "Project ID not found"
**Solution**:
- Go to Appwrite Console
- Click your project
- Settings → Project Settings
- Copy exact Project ID

## Variable Reference

| Variable | Value | Example |
|----------|-------|---------|
| `VITE_APPWRITE_ENDPOINT` | Always this | `https://cloud.appwrite.io/v1` |
| `NEXT_PUBLIC_APPWRITE_PROJECT_ID` | From Appwrite | `6789abcdef012345` |
| `NEXT_PUBLIC_APPWRITE_DATABASE_ID` | Your database ID | `papers_db_abc123` |
| `NEXT_PUBLIC_APPWRITE_COLLECTION_ID` | Fixed value | `question_papers` |
| `NEXT_PUBLIC_APPWRITE_BUCKET_ID` | Fixed value | `papers-bucket` |
| `ADMIN_EMAIL` | Your choice | `admin@university.edu` |
| `ADMIN_PASSWORD` | Your choice | `admin123` |

## Next Steps

Once configured, you can:
- Upload papers at `/admin/upload`
- Manage papers at `/admin/manage`
- View papers at `/cse`, `/entc`, etc.
- Download/view PDFs in student view

Happy learning! 📚
