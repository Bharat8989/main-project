# Quick Start - Paper Portal with Your .env.local

## 3-Minute Setup

### 1. Copy .env.local Template
```bash
cp .env.local.example .env.local
```

### 2. Fill Your .env.local with Your Credentials

Your `.env.local` file should look like this:

```bash
# ============================================
# APPWRITE CREDENTIALS (Get from Appwrite Console)
# ============================================
VITE_APPWRITE_ENDPOINT=https://cloud.appwrite.io/v1
NEXT_PUBLIC_APPWRITE_PROJECT_ID=YOUR_PROJECT_ID
NEXT_PUBLIC_APPWRITE_DATABASE_ID=YOUR_DATABASE_ID

# ============================================
# FIXED VALUES (Keep these as-is)
# ============================================
NEXT_PUBLIC_APPWRITE_COLLECTION_ID=question_papers
NEXT_PUBLIC_APPWRITE_BUCKET_ID=papers-bucket

# ============================================
# OPTIONAL ADMIN CREDENTIALS
# ============================================
ADMIN_EMAIL=admin@university.edu
ADMIN_PASSWORD=admin123

NODE_ENV=development
```

### 3. Where to Find Your Credentials

| Variable | Where to Find |
|----------|----------------|
| `NEXT_PUBLIC_APPWRITE_PROJECT_ID` | Appwrite Console → Your Project → Settings |
| `NEXT_PUBLIC_APPWRITE_DATABASE_ID` | Appwrite Console → Databases → Your DB → ID |
| `NEXT_PUBLIC_APPWRITE_COLLECTION_ID` | Keep as `question_papers` |
| `NEXT_PUBLIC_APPWRITE_BUCKET_ID` | Keep as `papers-bucket` |

### 4. Create Appwrite Resources

Before running, ensure these exist in Appwrite:

**Database Collection** (`question_papers`):
- title (String)
- department (String)
- year (Integer)
- semester (String)
- season (String)
- subject (String)
- fileId (String)
- fileName (String)
- uploadedAt (DateTime)
- uploadedBy (String)

**Storage Bucket** (`papers-bucket`):
- For storing PDF files

### 5. Run the Application

```bash
npm install
npm run dev
```

Open: http://localhost:3000

### 6. Test

1. Go to http://localhost:3000/admin
2. Login with:
   - Email: `admin@university.edu`
   - Password: `admin123`
3. Try uploading a test PDF at `/admin/upload`

## Your .env.local Format (Your Variables)

Based on your setup:
```
VITE_APPWRITE_ENDPOINT=https://cloud.appwrite.io/v1
NEXT_PUBLIC_APPWRITE_PROJECT_ID=<YOUR_ID>
NEXT_PUBLIC_APPWRITE_DATABASE_ID=<YOUR_ID>
NEXT_PUBLIC_APPWRITE_COLLECTION_ID=question_papers
NEXT_PUBLIC_APPWRITE_BUCKET_ID=papers-bucket
ADMIN_EMAIL=admin@university.edu
ADMIN_PASSWORD=admin123
```

## Code Using These Variables

The project automatically reads from your `.env.local`:

```typescript
// From lib/appwrite.ts
const endpoint = process.env.VITE_APPWRITE_ENDPOINT
const projectId = process.env.NEXT_PUBLIC_APPWRITE_PROJECT_ID
const databaseId = process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID
const collectionId = process.env.NEXT_PUBLIC_APPWRITE_COLLECTION_ID
const bucketId = process.env.NEXT_PUBLIC_APPWRITE_BUCKET_ID
```

All services automatically use these values!

## Troubleshooting

### Error: "undefined" in console
Make sure `.env.local` file is in the project root and all variables are set.

### Error: "Collection not found"
Verify collection name is exactly `question_papers` in Appwrite.

### Error: "Bucket not found"
Create storage bucket named `papers-bucket` in Appwrite.

For detailed setup, see `ENV_SETUP_YOUR_CREDENTIALS.md`

---

**That's it! Your Paper Portal is ready to use.** 🎉
