# Paper Portal - Appwrite Setup Checklist

Complete these steps to get your Paper Portal running with Appwrite backend.

---

## Phase 1: Appwrite Account Setup

- [ ] Create Appwrite Cloud account at https://cloud.appwrite.io
- [ ] Create a new Appwrite project
- [ ] Copy and save your **Project ID**
- [ ] Go to Settings → API Keys
- [ ] Create new API Key with required scopes:
  - [ ] databases.read
  - [ ] databases.write
  - [ ] collections.read
  - [ ] collections.write
  - [ ] documents.read
  - [ ] documents.write
  - [ ] documents.delete
  - [ ] files.read
  - [ ] files.write
  - [ ] files.delete
- [ ] Copy and save your **API Key** (keep this secret!)

---

## Phase 2: Database Setup

### Create Database
- [ ] Go to Appwrite Console → Databases
- [ ] Click "Create Database"
- [ ] Name: `papers_database`
- [ ] Copy the **Database ID**

### Create Collections

#### Papers Collection
- [ ] Create collection named `papers`
- [ ] Collection ID: `papers`
- [ ] Add attributes:
  - [ ] `title` (String, Required)
  - [ ] `department` (String, Required)
  - [ ] `year` (Integer, Required)
  - [ ] `semester` (String, Required)
  - [ ] `season` (String, Required)
  - [ ] `subject` (String, Required)
  - [ ] `fileId` (String, Required)
  - [ ] `fileName` (String, Required)
  - [ ] `uploadedAt` (DateTime, Required)
  - [ ] `uploadedBy` (String, Required)

#### Users Collection
- [ ] Create collection named `users`
- [ ] Collection ID: `users`
- [ ] Add attributes:
  - [ ] `email` (String, Required, Unique)
  - [ ] `name` (String)
  - [ ] `department` (String)
  - [ ] `enrollmentNo` (String)
  - [ ] `createdAt` (DateTime)

#### Admins Collection
- [ ] Create collection named `admins`
- [ ] Collection ID: `admins`
- [ ] Add attributes:
  - [ ] `email` (String, Required, Unique)
  - [ ] `name` (String)
  - [ ] `role` (String, Required)
  - [ ] `createdAt` (DateTime)

---

## Phase 3: Storage Setup

- [ ] Go to Appwrite Console → Storage
- [ ] Click "Create Bucket"
- [ ] Name: `papers_bucket`
- [ ] Copy the **Bucket ID**
- [ ] Set permissions:
  - [ ] Allow public read (for PDF preview/download)
  - [ ] Restrict write to authenticated users
- [ ] Set file size limits (recommended: 50MB max)
- [ ] Allow file types: PDF only

---

## Phase 4: Environment Configuration

- [ ] Copy `.env.example` to `.env.local`
  ```bash
  cp .env.example .env.local
  ```

- [ ] Fill in `.env.local` with your values:
  - [ ] `NEXT_PUBLIC_APPWRITE_ENDPOINT` = https://cloud.appwrite.io/v1
  - [ ] `NEXT_PUBLIC_APPWRITE_PROJECT_ID` = your_project_id
  - [ ] `APPWRITE_API_KEY` = your_api_key
  - [ ] `NEXT_PUBLIC_APPWRITE_DATABASE_ID` = papers_database
  - [ ] `NEXT_PUBLIC_APPWRITE_PAPERS_COLLECTION_ID` = papers
  - [ ] `NEXT_PUBLIC_APPWRITE_USERS_COLLECTION_ID` = users
  - [ ] `NEXT_PUBLIC_APPWRITE_ADMINS_COLLECTION_ID` = admins
  - [ ] `NEXT_PUBLIC_APPWRITE_BUCKET_ID` = papers_bucket

- [ ] Add `.env.local` to `.gitignore`
  ```
  .env.local
  .env.*.local
  ```

- [ ] Do NOT commit `.env.local` to version control

---

## Phase 5: Installation & Testing

- [ ] Install dependencies
  ```bash
  npm install
  ```

- [ ] Start development server
  ```bash
  npm run dev
  ```

- [ ] Open http://localhost:3000 in browser
- [ ] Verify homepage loads without errors
- [ ] Check console for any error messages

---

## Phase 6: Admin Testing

- [ ] Navigate to http://localhost:3000/admin
- [ ] Login with demo credentials:
  - Email: `admin@university.edu`
  - Password: `admin123`
- [ ] Should see admin dashboard
- [ ] Test uploading a paper:
  - [ ] Go to `/admin/upload`
  - [ ] Fill in paper details
  - [ ] Upload a test PDF file
  - [ ] Submit and verify it appears in `/admin/manage`
- [ ] Test paper deletion:
  - [ ] Go to `/admin/manage`
  - [ ] Click delete on test paper
  - [ ] Verify paper is removed

---

## Phase 7: Student Testing

- [ ] Go to http://localhost:3000
- [ ] Click on a department (e.g., CSE)
- [ ] Navigate to papers section
- [ ] Use filters (year, semester)
- [ ] Try to download/view papers
- [ ] Verify papers appear correctly

---

## Phase 8: Security Review

- [ ] Verify `.env.local` is in `.gitignore`
- [ ] Check API keys are not exposed in code
- [ ] Review Appwrite Console permissions
- [ ] Set up Row-Level Security (RLS) if needed
- [ ] Consider adding rate limiting
- [ ] Plan authentication for production

---

## Phase 9: Production Deployment

- [ ] Create `.env.production` with production values
- [ ] Update `NEXT_PUBLIC_APPWRITE_ENDPOINT` for production
- [ ] Generate new Appwrite API key for production
- [ ] Deploy to Vercel, Netlify, or your hosting
- [ ] Test all functionality on live site
- [ ] Set up monitoring and error tracking
- [ ] Plan backup strategy for database

---

## Phase 10: Documentation

- [ ] Read `APPWRITE_SETUP.md` for detailed guide
- [ ] Read `README.md` for general usage
- [ ] Document any customizations made
- [ ] Update team with credentials (securely)
- [ ] Create admin user guide
- [ ] Document backup procedures

---

## Troubleshooting

### Having issues?

Check these resources:
1. **APPWRITE_SETUP.md** - Detailed setup guide with troubleshooting
2. **Console errors** - Open browser dev tools (F12) and check console
3. **Network tab** - Check if API calls are successful
4. **Appwrite Console** - Verify databases and collections exist
5. **Environment variables** - Verify `.env.local` is correct

### Common Issues

| Issue | Solution |
|-------|----------|
| "Project not found" | Check PROJECT_ID in `.env.local` |
| "Invalid API Key" | Regenerate API key in Appwrite Console |
| "Collection not found" | Verify collection IDs match exactly |
| "File upload failed" | Check bucket exists and has write permissions |
| "Login not working" | Clear localStorage and try again |

---

## Quick Reference

```bash
# Copy environment template
cp .env.example .env.local

# Install packages
npm install

# Start development
npm run dev

# Build for production
npm run build

# Start production server
npm start
```

---

## Next Steps

Once setup is complete:
1. Upload initial set of papers
2. Create admin accounts for team members
3. Customize department structure
4. Set up analytics
5. Plan deployment strategy
6. Onboard users

---

## Support

For issues or questions:
- Check APPWRITE_SETUP.md
- Review Appwrite documentation: https://appwrite.io/docs
- Contact Appwrite support: https://appwrite.io/support
- Check project GitHub issues

Good luck! 🚀
