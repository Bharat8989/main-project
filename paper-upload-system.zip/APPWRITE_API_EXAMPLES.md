# Appwrite API Examples for Paper Portal

This document shows how to use the Appwrite services in your code.

---

## Table of Contents

1. [Paper Operations](#paper-operations)
2. [File Operations](#file-operations)
3. [Authentication](#authentication)
4. [Error Handling](#error-handling)
5. [Real-World Examples](#real-world-examples)

---

## Paper Operations

### Import the Service

```typescript
import {
  createPaper,
  getPapers,
  getPaper,
  updatePaper,
  deletePaper,
  uploadFile,
  getFileUrl,
  deleteFile,
} from '@/lib/papers-service'
```

### Create a New Paper

```typescript
async function handlePaperUpload(formData: any) {
  try {
    // Upload file first
    const file = formData.get('pdf') as File
    const fileId = await uploadFile(file)

    // Create paper record
    const paper = await createPaper(
      {
        title: formData.get('title'),
        department: formData.get('department'),
        year: parseInt(formData.get('year')),
        semester: formData.get('semester'),
        season: formData.get('season'),
        subject: formData.get('subject'),
        fileName: file.name,
      },
      fileId,
      'admin@university.edu'
    )

    console.log('Paper created:', paper)
    return paper
  } catch (error) {
    console.error('Failed to upload paper:', error)
    throw error
  }
}
```

### Get All Papers (No Filter)

```typescript
async function getAllPapers() {
  try {
    const papers = await getPapers()
    console.log('All papers:', papers)
    return papers
  } catch (error) {
    console.error('Failed to fetch papers:', error)
    throw error
  }
}
```

### Get Papers with Filters

```typescript
async function getCSEPapers() {
  try {
    const papers = await getPapers({
      department: 'cse',
      year: 2024,
      semester: '3',
    })

    console.log('CSE Semester 3 papers (2024):', papers)
    return papers
  } catch (error) {
    console.error('Failed to fetch CSE papers:', error)
    throw error
  }
}
```

### Get Single Paper

```typescript
async function viewPaper(paperId: string) {
  try {
    const paper = await getPaper(paperId)
    console.log('Paper details:', paper)

    // Get file URL
    const fileUrl = getFileUrl(paper.fileId)
    console.log('Download link:', fileUrl)

    return { paper, fileUrl }
  } catch (error) {
    console.error('Failed to fetch paper:', error)
    throw error
  }
}
```

### Update Paper Details

```typescript
async function updatePaperMetadata(paperId: string) {
  try {
    const updated = await updatePaper(paperId, {
      title: 'Updated DSA Question Paper',
      subject: 'Data Structures and Algorithms',
    })

    console.log('Paper updated:', updated)
    return updated
  } catch (error) {
    console.error('Failed to update paper:', error)
    throw error
  }
}
```

### Delete Paper

```typescript
async function removePaper(paperId: string, fileId: string) {
  try {
    // Delete file from storage
    await deleteFile(fileId)
    console.log('File deleted')

    // Delete paper record
    await deletePaper(paperId)
    console.log('Paper record deleted')

    return true
  } catch (error) {
    console.error('Failed to delete paper:', error)
    throw error
  }
}
```

---

## File Operations

### Upload File to Storage

```typescript
async function uploadPDF(file: File) {
  try {
    // Validate file
    if (!file.type.includes('pdf')) {
      throw new Error('Only PDF files are allowed')
    }

    if (file.size > 50 * 1024 * 1024) {
      throw new Error('File size exceeds 50MB limit')
    }

    // Upload
    const fileId = await uploadFile(file)
    console.log('File uploaded with ID:', fileId)
    return fileId
  } catch (error) {
    console.error('Upload failed:', error)
    throw error
  }
}
```

### Get File Download URL

```typescript
function generateDownloadLink(fileId: string) {
  try {
    const url = getFileUrl(fileId)
    console.log('Download URL:', url)
    return url
  } catch (error) {
    console.error('Failed to generate download link:', error)
    throw error
  }
}
```

### Delete File from Storage

```typescript
async function removeFile(fileId: string) {
  try {
    await deleteFile(fileId)
    console.log('File deleted successfully')
    return true
  } catch (error) {
    console.error('Failed to delete file:', error)
    throw error
  }
}
```

---

## Authentication

### Import Auth Service

```typescript
import {
  loginAdmin,
  logoutAdmin,
  getCurrentAdmin,
  isDemoAdmin,
  isAdminAuthenticated,
} from '@/lib/auth-service'
```

### Demo Login (Development)

```typescript
async function demoLogin(email: string, password: string) {
  try {
    // Check against demo credentials
    if (isDemoAdmin(email, password)) {
      // Create demo session in localStorage
      createDemoSession(email)
      console.log('Demo admin logged in')
      return true
    }
    throw new Error('Invalid credentials')
  } catch (error) {
    console.error('Login failed:', error)
    throw error
  }
}
```

### Check Authentication Status

```typescript
function checkAdminAuth() {
  const authenticated = isAdminAuthenticated()
  console.log('Is admin authenticated:', authenticated)

  if (!authenticated) {
    // Redirect to login
    window.location.href = '/admin'
  }

  return authenticated
}
```

### Logout

```typescript
function handleLogout() {
  try {
    // Clear demo session
    clearDemoSession()
    console.log('Admin logged out')

    // Redirect to home
    window.location.href = '/'
  } catch (error) {
    console.error('Logout failed:', error)
  }
}
```

---

## Error Handling

### Comprehensive Error Handling

```typescript
async function safePaperOperation() {
  try {
    const papers = await getPapers({ department: 'cse' })
    return papers
  } catch (error) {
    // Handle different error types
    if (error instanceof Error) {
      if (error.message.includes('Project not found')) {
        console.error('Appwrite project configuration error')
      } else if (error.message.includes('Invalid API Key')) {
        console.error('API key authentication failed')
      } else if (error.message.includes('Collection not found')) {
        console.error('Database schema is not properly set up')
      } else {
        console.error('General error:', error.message)
      }
    }

    // User-friendly error message
    return {
      success: false,
      message: 'Failed to load papers. Please try again.',
    }
  }
}
```

---

## Real-World Examples

### Example 1: Complete Paper Upload Flow

```typescript
'use client'

import { useState } from 'react'
import { uploadFile, createPaper } from '@/lib/papers-service'

export default function PaperUploadForm() {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      const formData = new FormData(e.currentTarget)

      // 1. Upload file
      const pdfFile = formData.get('pdf') as File
      if (!pdfFile) throw new Error('No file selected')

      const fileId = await uploadFile(pdfFile)
      console.log('[v0] File uploaded:', fileId)

      // 2. Create paper record
      const paper = await createPaper(
        {
          title: formData.get('title') as string,
          department: formData.get('department') as string,
          year: parseInt(formData.get('year') as string),
          semester: formData.get('semester') as string,
          season: formData.get('season') as string,
          subject: formData.get('subject') as string,
          fileName: pdfFile.name,
        },
        fileId,
        'admin@university.edu'
      )

      console.log('[v0] Paper created:', paper)
      alert('Paper uploaded successfully!')
      e.currentTarget.reset()
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Upload failed'
      setError(message)
      console.error('[v0] Upload error:', err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <input type="text" name="title" placeholder="Paper Title" required />
      <input type="file" name="pdf" accept=".pdf" required />
      <button disabled={loading}>{loading ? 'Uploading...' : 'Upload'}</button>
      {error && <p className="error">{error}</p>}
    </form>
  )
}
```

### Example 2: Paper List with Filters

```typescript
'use client'

import { useState, useEffect } from 'react'
import { getPapers, getFileUrl, type Paper } from '@/lib/papers-service'

export default function PapersList() {
  const [papers, setPapers] = useState<Paper[]>([])
  const [loading, setLoading] = useState(true)
  const [year, setYear] = useState<number | null>(null)
  const [semester, setSemester] = useState<string | null>(null)

  useEffect(() => {
    loadPapers()
  }, [year, semester])

  async function loadPapers() {
    try {
      setLoading(true)
      const data = await getPapers({
        department: 'cse',
        ...(year && { year }),
        ...(semester && { semester }),
      })
      console.log('[v0] Loaded papers:', data)
      setPapers(data)
    } catch (error) {
      console.error('[v0] Failed to load papers:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div>
      <select onChange={(e) => setYear(e.target.value ? parseInt(e.target.value) : null)}>
        <option value="">All Years</option>
        <option value="2024">2024</option>
        <option value="2023">2023</option>
      </select>

      <select onChange={(e) => setSemester(e.target.value || null)}>
        <option value="">All Semesters</option>
        <option value="1">Semester 1</option>
        <option value="3">Semester 3</option>
      </select>

      {loading && <p>Loading...</p>}

      <div>
        {papers.map((paper) => (
          <div key={paper.$id}>
            <h3>{paper.title}</h3>
            <p>{paper.subject} - {paper.year}</p>
            <a href={getFileUrl(paper.fileId)} target="_blank">
              Download PDF
            </a>
          </div>
        ))}
      </div>
    </div>
  )
}
```

### Example 3: Admin Paper Management

```typescript
'use client'

import { useState, useEffect } from 'react'
import { getPapers, deletePaper, deleteFile, type Paper } from '@/lib/papers-service'

export default function AdminPaperManager() {
  const [papers, setPapers] = useState<Paper[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    loadPapers()
  }, [])

  async function loadPapers() {
    try {
      const data = await getPapers()
      console.log('[v0] Admin loaded papers:', data)
      setPapers(data)
    } catch (error) {
      console.error('[v0] Failed to load papers:', error)
    }
  }

  async function handleDelete(paper: Paper) {
    if (!confirm(`Delete "${paper.title}"?`)) return

    try {
      setLoading(true)
      console.log('[v0] Deleting paper:', paper.$id)

      // Delete file
      await deleteFile(paper.fileId)
      console.log('[v0] File deleted')

      // Delete record
      await deletePaper(paper.$id)
      console.log('[v0] Paper deleted')

      // Refresh list
      await loadPapers()
      alert('Paper deleted successfully')
    } catch (error) {
      console.error('[v0] Delete error:', error)
      alert('Failed to delete paper')
    } finally {
      setLoading(false)
    }
  }

  return (
    <table>
      <thead>
        <tr>
          <th>Title</th>
          <th>Department</th>
          <th>Year</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {papers.map((paper) => (
          <tr key={paper.$id}>
            <td>{paper.title}</td>
            <td>{paper.department}</td>
            <td>{paper.year}</td>
            <td>
              <button
                onClick={() => handleDelete(paper)}
                disabled={loading}
              >
                Delete
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}
```

---

## Best Practices

1. **Always validate data** before uploading
2. **Use try-catch** for all async operations
3. **Log important events** with `console.log('[v0] ...')`
4. **Check authentication** before admin operations
5. **Handle errors gracefully** with user-friendly messages
6. **Limit file size** before upload
7. **Validate file type** (PDF only)
8. **Use correct environment variables** in .env.local
9. **Never expose API keys** in client code
10. **Test thoroughly** before production

---

## Additional Resources

- [Appwrite Documentation](https://appwrite.io/docs)
- [Paper Portal README](./README.md)
- [Appwrite Setup Guide](./APPWRITE_SETUP.md)
- [TypeScript Docs](https://www.typescriptlang.org/docs)

---

Need help? Check APPWRITE_SETUP.md or contact support! 🚀
