# Paper Portal - Appwrite Backend Integration

Complete backend integration with Appwrite for your Paper Portal application!

---

## What's Included

✅ **Appwrite SDK Integration** - Ready to connect  
✅ **Paper Management Service** - CRUD operations for papers  
✅ **File Upload Service** - PDF storage and management  
✅ **Authentication Service** - Admin login/logout  
✅ **Environment Configuration** - .env templates  
✅ **Comprehensive Documentation** - Setup guides and examples  

---

## Quick Start (5 minutes)

### 1. Create Appwrite Account
Visit [Appwrite Cloud](https://cloud.appwrite.io) and create a project

### 2. Get Your Credentials
- Copy your **Project ID**
- Create an **API Key** with database and storage scopes
- Note your **Endpoint** (https://cloud.appwrite.io/v1)

### 3. Setup Environment
```bash
# Copy the example file
cp .env.example .env.local

# Edit .env.local with your credentials
# Fill in: PROJECT_ID, API_KEY, DATABASE_ID, etc.
```

### 4. Create Database Structure
In Appwrite Console, create:
- **Database:** `papers_database`
- **Collections:** papers, users, admins
- **Bucket:** papers_bucket

See **APPWRITE_SETUP.md** for detailed steps with screenshots.

### 5. Run & Test
```bash
npm install
npm run dev
# Open http://localhost:3000
# Login: admin@university.edu / admin123
```

---

## File Structure

```
paper-portal/
├── .env.example                 # Template for environment variables
├── .env.local.example           # Detailed .env.local example
├── lib/
│   ├── appwrite.ts             # Appwrite client initialization
│   ├── papers-service.ts        # Paper CRUD operations
│   └── auth-service.ts          # Admin authentication
├── APPWRITE_README.md          # This file
├── APPWRITE_SETUP.md           # Detailed setup guide
├── APPWRITE_CHECKLIST.md       # Step-by-step checklist
└── APPWRITE_API_EXAMPLES.md    # Code examples & usage
```

---

## Documentation Files

| File | Purpose |
|------|---------|
| **APPWRITE_README.md** (this file) | Quick overview and links |
| **APPWRITE_SETUP.md** | Complete setup guide with troubleshooting |
| **APPWRITE_CHECKLIST.md** | Step-by-step checklist with all tasks |
| **APPWRITE_API_EXAMPLES.md** | Real-world code examples |

**Start with APPWRITE_SETUP.md for the full guide!**

---

## Available Services

### Paper Service (`lib/papers-service.ts`)

**Upload Papers:**
```typescript
const fileId = await uploadFile(pdfFile)
await createPaper({
  title: 'DSA Paper',
  department: 'cse',
  year: 2024,
  semester: '3',
  season: 'Winter',
  subject: 'Data Structures',
  fileName: 'dsa.pdf'
}, fileId, 'admin@email.com')
```

**Get Papers:**
```typescript
// Get all papers
const all = await getPapers()

// Get filtered papers
const cse = await getPapers({
  department: 'cse',
  year: 2024,
  semester: '3'
})

// Get single paper
const paper = await getPaper(paperId)
```

**Update Papers:**
```typescript
await updatePaper(paperId, {
  title: 'Updated Title',
  subject: 'New Subject'
})
```

**Delete Papers:**
```typescript
await deletePaper(paperId)
await deleteFile(fileId)
```

### Auth Service (`lib/auth-service.ts`)

**Login:**
```typescript
// Demo login (development)
if (isDemoAdmin('admin@university.edu', 'admin123')) {
  createDemoSession('admin@university.edu')
}
```

**Check Auth Status:**
```typescript
if (isAdminAuthenticated()) {
  // User is logged in
}
```

**Logout:**
```typescript
clearDemoSession()
```

---

## Environment Variables

```env
# Required - Appwrite Connection
NEXT_PUBLIC_APPWRITE_ENDPOINT=https://cloud.appwrite.io/v1
NEXT_PUBLIC_APPWRITE_PROJECT_ID=your_project_id
APPWRITE_API_KEY=your_api_key

# Required - Database & Collections
NEXT_PUBLIC_APPWRITE_DATABASE_ID=papers_database
NEXT_PUBLIC_APPWRITE_PAPERS_COLLECTION_ID=papers
NEXT_PUBLIC_APPWRITE_USERS_COLLECTION_ID=users
NEXT_PUBLIC_APPWRITE_ADMINS_COLLECTION_ID=admins

# Required - Storage
NEXT_PUBLIC_APPWRITE_BUCKET_ID=papers_bucket

# Optional - Demo Credentials
ADMIN_EMAIL=admin@university.edu
ADMIN_PASSWORD=admin123

# Application
NEXT_PUBLIC_APP_NAME=Paper Portal
NEXT_PUBLIC_APP_URL=http://localhost:3000
NODE_ENV=development
```

See `.env.local.example` for detailed descriptions.

---

## Database Schema

### Papers Collection
```javascript
{
  title: String,              // Paper title
  department: String,         // cse, entc, civil, etc.
  year: Integer,              // 2024, 2023, etc.
  semester: String,           // 1, 2, 3, 4, 5, 6, 7, 8
  season: String,             // Summer, Winter, Regular
  subject: String,            // Subject name
  fileId: String,             // Appwrite file ID
  fileName: String,           // Original filename
  uploadedAt: DateTime,       // Upload timestamp
  uploadedBy: String          // Admin email
}
```

### Users Collection
```javascript
{
  email: String,              // Unique student email
  name: String,               // Student name
  department: String,         // Home department
  enrollmentNo: String,       // Enrollment number
  createdAt: DateTime         // Account creation time
}
```

### Admins Collection
```javascript
{
  email: String,              // Unique admin email
  name: String,               // Admin name
  role: String,               // admin or superadmin
  createdAt: DateTime         // Account creation time
}
```

---

## Common Tasks

### Upload a Paper
1. Go to `/admin/dashboard`
2. Click "Upload Papers"
3. Fill in details (title, department, year, semester, season, subject)
4. Select PDF file
5. Click "Upload"
6. Paper appears in `/admin/manage`

### View Papers (Student)
1. Visit homepage
2. Click department (e.g., "CSE")
3. Click "Browse Papers"
4. Use filters to find papers
5. Click paper to preview/download

### Delete Papers (Admin)
1. Go to `/admin/manage`
2. Find paper in list
3. Click "Delete"
4. Confirm deletion

### Filter Papers
- **By Year:** 2024, 2023, 2022...
- **By Semester:** 1, 2, 3, 4, 5, 6, 7, 8
- **By Season:** Summer, Winter, Regular
- **By Department:** CSE, ENTC, Civil, IE, Mechanical, Electrical

---

## Troubleshooting

### Issue: "Project not found"
**Solution:** Check `NEXT_PUBLIC_APPWRITE_PROJECT_ID` in `.env.local`

### Issue: "Invalid API Key"
**Solution:** Verify API key in `.env.local` and regenerate if needed

### Issue: "Collection not found"
**Solution:** Ensure all collections are created in Appwrite Console

### Issue: "File upload fails"
**Solution:** Check bucket exists and has write permissions

### Issue: "Papers don't appear"
**Solution:** Verify database connection and collection IDs

For more issues, see **APPWRITE_SETUP.md** troubleshooting section.

---

## Security Best Practices

✅ **Use .env.local** for sensitive variables  
✅ **Never commit .env.local** to git  
✅ **Keep API keys secret** - don't share in code  
✅ **Use public keys** for client-side only (`NEXT_PUBLIC_` prefix)  
✅ **Validate file uploads** - check type and size  
✅ **Protect admin routes** - add authentication checks  
✅ **Set RLS policies** - restrict data access  
✅ **Use HTTPS** - secure data in transit  
✅ **Rotate API keys** - periodically refresh credentials  
✅ **Monitor access** - track who uploads/deletes papers  

---

## Production Deployment

### Before Going Live

- [ ] Test all features thoroughly
- [ ] Set up monitoring/error tracking
- [ ] Review security settings
- [ ] Create backup strategy
- [ ] Plan disaster recovery
- [ ] Document admin procedures
- [ ] Train administrators
- [ ] Create user documentation

### Environment Setup

Create `.env.production` with:
- Production Appwrite endpoint
- Production API key
- Production database IDs
- Updated `NEXT_PUBLIC_APP_URL`

### Deployment Platforms

Works with:
- Vercel (recommended)
- Netlify
- AWS Amplify
- Any Node.js hosting

---

## Support & Resources

### Documentation
- [APPWRITE_SETUP.md](./APPWRITE_SETUP.md) - Full setup guide
- [APPWRITE_CHECKLIST.md](./APPWRITE_CHECKLIST.md) - Setup checklist
- [APPWRITE_API_EXAMPLES.md](./APPWRITE_API_EXAMPLES.md) - Code examples

### External Links
- [Appwrite Website](https://appwrite.io)
- [Appwrite Documentation](https://appwrite.io/docs)
- [Appwrite Cloud Console](https://cloud.appwrite.io)
- [Next.js Documentation](https://nextjs.org/docs)

### Getting Help
1. Check the troubleshooting section above
2. Review APPWRITE_SETUP.md
3. Check browser console for errors
4. Review Appwrite Console logs
5. Contact Appwrite support

---

## Next Steps

1. **Setup:** Follow APPWRITE_SETUP.md
2. **Checklist:** Complete APPWRITE_CHECKLIST.md
3. **Code:** Review APPWRITE_API_EXAMPLES.md
4. **Test:** Login and upload a paper
5. **Deploy:** Push to production

---

## Project Status

✅ Backend integration: Complete  
✅ Paper management: Complete  
✅ File upload: Complete  
✅ Admin authentication: Complete  
✅ Documentation: Complete  

Ready for production deployment! 🚀

---

## License & Support

This project is part of Paper Portal.
For support, check the documentation or contact your development team.

Last Updated: 2025  
Version: 1.0
