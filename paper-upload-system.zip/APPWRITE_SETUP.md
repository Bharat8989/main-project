# Appwrite Setup Guide for Paper Portal

## Overview
This guide explains how to set up and integrate Appwrite with your Paper Portal application. Appwrite provides the backend infrastructure for storing papers, managing users, and handling file uploads.

---

## Prerequisites
- Node.js 16+ installed
- npm or yarn package manager
- Appwrite account (https://cloud.appwrite.io)
- Basic understanding of databases and API keys

---

## Step 1: Create Appwrite Project

1. Go to [Appwrite Cloud](https://cloud.appwrite.io)
2. Sign up or log in to your account
3. Create a new project
4. Copy your **Project ID** (you'll need this)
5. Go to Settings → API Keys
6. Create a new API key with the following scopes:
   - `databases.read`
   - `databases.write`
   - `collections.read`
   - `collections.write`
   - `documents.read`
   - `documents.write`
   - `documents.delete`
   - `files.read`
   - `files.write`
   - `files.delete`
7. Copy the **API Key** (save this securely)

---

## Step 2: Create Database and Collections

In your Appwrite console:

### Create Database
1. Go to **Databases** section
2. Create a new database named `papers_database`
3. Copy the **Database ID**

### Create Collections

#### 1. Papers Collection
- **Name:** papers
- **Collection ID:** papers

**Attributes:**
- `title` (String, Required)
- `department` (String, Required)
- `year` (Integer, Required)
- `semester` (String, Required, Options: "1", "2", "3", "4", "5", "6", "7", "8")
- `season` (String, Required, Options: "Summer", "Winter", "Regular")
- `subject` (String, Required)
- `fileId` (String, Required)
- `fileName` (String, Required)
- `uploadedAt` (DateTime, Required)
- `uploadedBy` (String, Required)

#### 2. Users Collection (Optional)
- **Name:** users
- **Collection ID:** users

**Attributes:**
- `email` (String, Required, Unique)
- `name` (String)
- `department` (String)
- `enrollmentNo` (String)
- `createdAt` (DateTime)

#### 3. Admins Collection
- **Name:** admins
- **Collection ID:** admins

**Attributes:**
- `email` (String, Required, Unique)
- `name` (String)
- `role` (String, Required, Options: "admin", "superadmin")
- `createdAt` (DateTime)

---

## Step 3: Create Storage Bucket

1. Go to **Storage** section
2. Create a new bucket named `papers_bucket`
3. Copy the **Bucket ID**
4. Set permissions:
   - Allow public read for PDFs
   - Restrict write to authenticated admins

---

## Step 4: Configure Environment Variables

1. Copy `.env.example` to `.env.local`:
```bash
cp .env.example .env.local
```

2. Fill in your Appwrite credentials in `.env.local`:
```env
# Appwrite Configuration
NEXT_PUBLIC_APPWRITE_ENDPOINT=https://cloud.appwrite.io/v1
NEXT_PUBLIC_APPWRITE_PROJECT_ID=your_project_id_here
APPWRITE_API_KEY=your_api_key_here

# Database Configuration
NEXT_PUBLIC_APPWRITE_DATABASE_ID=papers_database
NEXT_PUBLIC_APPWRITE_PAPERS_COLLECTION_ID=papers
NEXT_PUBLIC_APPWRITE_USERS_COLLECTION_ID=users
NEXT_PUBLIC_APPWRITE_ADMINS_COLLECTION_ID=admins

# Bucket Configuration
NEXT_PUBLIC_APPWRITE_BUCKET_ID=papers_bucket

# Admin Credentials
ADMIN_EMAIL=admin@university.edu
ADMIN_PASSWORD=admin123

# Application Settings
NEXT_PUBLIC_APP_NAME=Paper Portal
NEXT_PUBLIC_APP_URL=http://localhost:3000
NODE_ENV=development
```

3. **Important:** Never commit `.env.local` to version control. Add to `.gitignore`:
```
.env.local
.env.*.local
```

---

## Step 5: Install Appwrite SDK

The project already includes the Appwrite SDK. If you need to reinstall:

```bash
npm install appwrite
```

---

## Step 6: Test the Setup

1. Start the development server:
```bash
npm run dev
```

2. Visit http://localhost:3000

3. Test admin login:
   - Email: `admin@university.edu`
   - Password: `admin123`

4. Try uploading a paper from `/admin/upload`

---

## Available Services

### Paper Service (`lib/papers-service.ts`)
- `createPaper()` - Create a new paper
- `getPapers()` - Fetch papers with filters
- `getPaper()` - Get single paper
- `updatePaper()` - Update paper details
- `deletePaper()` - Delete a paper
- `uploadFile()` - Upload PDF file
- `deleteFile()` - Delete PDF file
- `getFileUrl()` - Get file download URL

### Auth Service (`lib/auth-service.ts`)
- `loginAdmin()` - Admin login
- `logoutAdmin()` - Admin logout
- `getCurrentAdmin()` - Get current user
- `isDemoAdmin()` - Check demo credentials
- `isAdminAuthenticated()` - Check auth status

---

## Environment Variables Explained

| Variable | Description | Example |
|----------|-------------|---------|
| `NEXT_PUBLIC_APPWRITE_ENDPOINT` | Appwrite API endpoint | https://cloud.appwrite.io/v1 |
| `NEXT_PUBLIC_APPWRITE_PROJECT_ID` | Your Appwrite project ID | 123abc456def |
| `APPWRITE_API_KEY` | Appwrite API key (server-only) | secret_key_here |
| `NEXT_PUBLIC_APPWRITE_DATABASE_ID` | Database ID | papers_database |
| `NEXT_PUBLIC_APPWRITE_PAPERS_COLLECTION_ID` | Papers collection ID | papers |
| `NEXT_PUBLIC_APPWRITE_BUCKET_ID` | Storage bucket ID | papers_bucket |

---

## Security Best Practices

1. **Never expose API keys in client code**
   - Use `NEXT_PUBLIC_` prefix only for IDs and endpoints
   - Keep `APPWRITE_API_KEY` server-side only

2. **Use Row-Level Security**
   - Set proper permissions on collections
   - Restrict write access to authenticated admins

3. **Validate file uploads**
   - Check file size
   - Validate file type (PDF only)
   - Scan for malware

4. **Protect admin routes**
   - Add authentication middleware
   - Use secure session management
   - Implement rate limiting

---

## Troubleshooting

### Error: "Project not found"
- Check your `NEXT_PUBLIC_APPWRITE_PROJECT_ID`
- Ensure project exists in Appwrite console

### Error: "Invalid API Key"
- Verify `APPWRITE_API_KEY` is correct
- Check API key has required scopes
- Regenerate key if needed

### Error: "Collection not found"
- Ensure all collections are created
- Check collection IDs match in `.env.local`
- Verify permissions are set correctly

### Files not uploading
- Check bucket exists and is enabled
- Verify file size limits
- Check file format (PDF only)
- Ensure bucket has write permissions

---

## Using the Services

### Example: Upload a paper
```typescript
import { uploadFile, createPaper } from '@/lib/papers-service'

const file = new File([...], 'paper.pdf')
const fileId = await uploadFile(file)
await createPaper(
  {
    title: 'DSA Question Paper',
    department: 'cse',
    year: 2023,
    semester: '3',
    season: 'Winter',
    subject: 'Data Structures',
    fileName: 'DSA_Winter_2023.pdf',
  },
  fileId,
  'admin@university.edu'
)
```

### Example: Get papers with filters
```typescript
import { getPapers } from '@/lib/papers-service'

const papers = await getPapers({
  department: 'cse',
  year: 2023,
  semester: '3',
})
```

---

## Next Steps

1. Complete the Appwrite setup above
2. Update your `.env.local` with real credentials
3. Test the admin login
4. Start uploading papers
5. Customize the department structure as needed
6. Deploy to production

---

## Additional Resources

- [Appwrite Documentation](https://appwrite.io/docs)
- [Appwrite JavaScript SDK](https://appwrite.io/docs/sdks/javascript)
- [Appwrite Cloud Console](https://cloud.appwrite.io)
- [Paper Portal README](./README.md)

---

## Support

If you encounter issues:
1. Check the Appwrite status page
2. Review the troubleshooting section above
3. Check console logs for error messages
4. Contact Appwrite support

Good luck with your Paper Portal! 🚀
